# Introduction to Deep Learning
#
This tutorial requires MNIST data.  This data currently lives on
The PSG cluster as /data/shared/ctierney/dl_tutorial_data.tar.bz2 
